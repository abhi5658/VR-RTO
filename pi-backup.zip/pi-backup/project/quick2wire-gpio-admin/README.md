GPIO Admin
==========

**This code is no longer necessary**, and the instructions for installing it will no longer work.

I will update the README with links to current instructions
about accessing GPIO pins. Until then, you are recommended to use
either RPi.GPIO or (GPIO zero)[https://www.raspberrypi.org/blog/gpio-zero-a-friendly-python-api-for-physical-computing/]

## Quick2Wire reeborn

I am currently in the process of updating the Quick2Wire codebase and documentation.

You can follow progress on (RAREblog)[http://blog.rareschool.com/]

