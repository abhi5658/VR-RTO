var gpio = require("pi-gpio");

gpio.open(11,"input pulldown",function (err) {
	if(err) {
		console.log("Error in open input pulldown : " + err);
	}
});
var inte = setInterval(function(){
gpio.read(11,function (err,value) {
	if(err) {
		console.log("Error in read : " + err);
	}
	gear = value;
	console.log("value : " + value);
});
},100);