const ADXL345 = require('adxl345-sensor');
const adxl345 = new ADXL345(); // defaults to i2cBusNo 1, i2cAddress 0x53

// Read ADXL345 three-axis acceleration, repeat
//
var adxlStart = 0;
var brake_offset,brake_range;
const setOffset = () => {
adxl345.getAcceleration(true) // true for g-force units, else false for m/s²
.then((acceleration) => {
  adxlStart = acceleration.x;
  console.log("Adxl start."+adxlStart);
  brake_offset = Math.ceil(adxlStart*10)+1;
  brake_range = 11 - brake_offset;
  console.log("offset : "+brake_offset + "\t adxlStart : "+adxlStart);

})
.catch((err) => {
  console.log(`ADXL345 read error: ${err}`);
});
};

brake_offset = Math.ceil(adxlStart*10)+2;
brake_range = 12 - brake_offset;
console.log("offset : "+brake_offset + "\t adxlStart : "+adxlStart);


var brake_x;
var inte = setInterval(function(){

  adxl345.getAcceleration(true) // true for g-force units, else false for m/s²
  .then((acceleration) => {
    brake_x = (acceleration.x)*10;

    if(brake_x > 11)
      brake_x=11;
    else if(brake_x < brake_offset)
      brake_x = brake_offset;

    brake_x = brake_x - brake_offset;

  //ranging the data b/w 0 and 1
  brake_x = brake_x / brake_range;

  console.log('x : '+Number(brake_x).toFixed(1) + " \tvalue : "+ acceleration.x*10);
      // setTimeout(getAcceleration, 1000);
    })
  .catch((err) => {
    console.log(`ADXL345 read error: ${err}`);
    setTimeout(getAcceleration, 2000);
  });
},100);

// Initialize the ADXL345 accelerometer
//
adxl345.init()
.then(() => {
  setOffset();
  console.log('ADXL345 initialization succeeded');
    // getAcceleration();
  })
.catch((err) => console.error(`ADXL345 initialization failed: ${err} `));