var express = require('express');
var app =express();
var http = require('http');
var server = http.createServer(app);
var io = require('socket.io').listen(server);

var i2c = require('i2c-bus');
var MPU6050 = require('i2c-mpu6050');
const ADXL345 = require('adxl345-sensor');
var gpio = require("pi-gpio");


var rot_address = 0x68;
var acc_address = 0x69;

var i2c1 = i2c.openSync(1);

var rot_sensor = new MPU6050(i2c1, rot_address);
var acc_sensor = new MPU6050(i2c1, acc_address);
const adxl345 = new ADXL345(); // defaults to i2cBusNo 1, i2cAddress 0x53


var convertedData={
	"R" : 0,
	"A" : 0,
	"B" : 0
};

//error coorection for rotation data
var rot_max_error = 3;
var rot_offset = rot_sensor.readSync().rotation.z;
var rot_up_error = rot_offset +rot_max_error;
var rot_down_error = rot_offset - rot_max_error;


//error coorection for acceleration data
var acc_offset = Math.ceil(acc_sensor.readSync().rotation.z);
var acc_range = -18 - acc_offset;


//error coorection for brake data
var adxlStart = 0;
var brake_offset,brake_range,brake_x = 0,gear=0;

const setOffset = () => {
adxl345.getAcceleration(true) // true for g-force units, else false for m/s²
.then((acceleration) => {
	adxlStart = acceleration.x;
	console.log("Adxl start."+adxlStart);
	brake_offset = Math.ceil(adxlStart*10)+1;
	brake_range = 11 - brake_offset;
	console.log("offset : "+brake_offset + "\t adxlStart : "+adxlStart);

})
.catch((err) => {
	console.log(`ADXL345 read error: ${err}`);
});
};


// Initialize the ADXL345 accelerometer
//
adxl345.init()
.then(() => {
	setOffset();
	console.log('ADXL345 initialization succeeded');
    // getAcceleration();
})
.catch((err) => console.error(`ADXL345 initialization failed: ${err} `));

//Initialize the gear button

gpio.open(11,"input pulldown",function (err) {
	if(err) {
		console.log("Error in open : " + err);
	}
});

/*var inte = setInterval(function(){

	//reading rot data
	var rot_data = rot_sensor.readSync();
	var rot_z = rot_data.rotation.z;
	var temp = rot_z;

	//correcting rotational data with initial point aka offset
	if(rot_z >= rot_down_error && rot_z <= rot_up_error)
		rot_z = 0;
	else
		rot_z = rot_z - rot_offset;

	//ranging the data b/w 0 and 1
	rot_z = rot_z/50;
	if(rot_z > 1)
		rot_z=1;
	else if(rot_z<-1)
		rot_z=-1;

	///reading acc data
	var acc_data = acc_sensor.readSync();
	var acc_z = acc_data.rotation.x;

	//correcting rotational data with initial point aka offset
	if(acc_z > 10)
		acc_z=10;
	else if(acc_z<acc_offset)
		acc_z=acc_offset;

	acc_z = acc_z - acc_offset;

	//ranging the data b/w 0 and 1
	acc_z = acc_z / acc_range;

	console.log("rot : "+ rot+"\tacc : "+ Number(acc_z).toFixed(1) + "\trot : "+ rot_data.rotation.z);

	},100);
	*/
	io.on("connection",function(socket){
		socket.on("disconnect",function(){
			console.log("user disconneted");
			clearInterval(inte);
		});

		console.log('car controller connected');
		var inte = setInterval(function(){

	//reading rot data
	var rot_data = rot_sensor.readSync();
	var rot_z = rot_data.rotation.z;

	//correcting rotational data with initial point aka offset
	if(rot_z >= rot_down_error && rot_z <= rot_up_error)
		rot_z = 0;
	else
		rot_z = rot_z - rot_offset;

	//ranging the data b/w 0 and 1
	rot_z = rot_z/50;
	if(rot_z > 1)
		rot_z=1;
	else if(rot_z<-1)
		rot_z=-1;

	///reading acc data
	var acc_data = acc_sensor.readSync();
	var acc_z = acc_data.rotation.z;
	// console.log("X : "+Number(acc_data.rotation.x).toFixed(2)+"\tY : "+Number(acc_data.rotation.y).toFixed(2)+"\tZ : "+Number(acc_data.rotation.z).toFixed(2));
	//correcting acceleration data with initial point aka offset
	if(acc_z < -28)
		acc_z = -28;
	else if(acc_z > 8)
		acc_z = 8;

	acc_z = (acc_z+28)/(36);
	

	adxl345.getAcceleration(true) // true for g-force units, else false for m/s²
	.then((acceleration) => {
		brake_x = (acceleration.x)*10;
		// console.log("sensor Data"+brake_x);

		if(brake_x < 9.6)
			brake_x=9.6;
		else if(brake_x > 11)
			brake_x = 11;

		brake_x = (brake_x-9.6)/1.4;
			// console.log("data  :"+brake_x);
		// console.log("brake_x : "+ brake_x + "\tbrakerange : "+brake_range);
  	//ranging the data b/w 0 and 1
  	// brake_x = brake_x / brake_range;
  	// console.log("Afteer brake_x : "+Number(brake_x).toFixed(1));

  })
	.catch((err) => {
		console.log(`ADXL345 read error: ${err}`);
	});

	gpio.read(11,function (err,value) {
		if(err) {
			console.log("Error in read : " + err);
		}
		gear = value;
		// console.log("value : " + value);
		});
	// console.log("sensor data : "+acceleration.x);

	console.log("rot : "+ Number(rot_z).toFixed(1)+"\tacc : "+ Number(acc_z).toFixed(1) +"\t brake : "+ Number(brake_x).toFixed(1)+"\t gear : "+gear);

	convertedData.R = Number(rot_z).toFixed(1);
	if(gear == 0){
		convertedData.A = Number(acc_z).toFixed(1);
	}
	else{
		convertedData.A = Number(acc_z * -1).toFixed(1);
	}
	convertedData.B = Number(brake_x).toFixed(1);

	socket.emit("datarec",convertedData);
	// console.log("z : "+ convertedData.R);
},100);

	});

	server.listen(3000,function(){
		console.log("server is running");
	});
